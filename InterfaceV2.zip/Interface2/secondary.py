import tkinter as tk
from PIL import Image, ImageTk
import serial

class SetUpScoreWindow:
    def __init__(self, root, list_of_numbers, file_name):
        #string of notes
        self.angles = list_of_numbers
        #index of current note
        self.index = 0
        #set up window
        self.root = root
        self.root.wm_iconbitmap("TheraNoteIcon.ico")
        self.root.title("TheraNote")
        self.root.geometry("1200x900")
        #set up frame for text
        self.create_number_frame()
        self.create_serial_frame()
        #set up canvas for image
        self.create_image_canvas(file_name)
        self.create_serial_object()

    #create frame for stings of numbers
    def create_number_frame(self):
        self.number_frame = tk.Frame(self.root)
        self.number_frame.grid(row=1, column=0)
        self.number_label = tk.Label(self.number_frame, text="Next Angle: " + self.angles[0], font=("Arial", 45))
        self.number_label.pack(pady=30)

    # create frame for serial data
    def create_serial_frame(self):
        self.serial_frame = tk.Frame(self.root)
        self.serial_frame.grid(row=2, column=0)
        self.serial_label = tk.Label(self.serial_frame, text="Current Angle: " + self.angles[0], font=("Arial", 50))
        self.serial_label.pack(pady=20)

    # create canvas for image
    def create_image_canvas(self, file_name):
        self.canvas = tk.Canvas(self.root, width=1200, height=500)
        self.canvas.grid(row=0, column=0, padx=30, pady=30)

    #format image
        image = Image.open(file_name)
        aspect_ratio = image.width / image.height
        new_width = 1200
        new_height = int(new_width / aspect_ratio)
        image = image.resize((new_width, new_height), Image.ANTIALIAS)
        self.photo = ImageTk.PhotoImage(image)

        self.image_frame = tk.Frame(self.canvas)
        self.canvas.create_window((0, 0), window=self.image_frame)

        self.image_label = tk.Label(self.image_frame, image=self.photo)
        self.image_label.pack()

        self.scrollbar = tk.Scrollbar(self.root, orient=tk.VERTICAL, command=self.canvas.yview)
        self.scrollbar.grid(row=0, column=1, sticky="ns")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        self.image_frame.update_idletasks()
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

        self.canvas.bind_all("<MouseWheel>", self.on_canvas_scroll)

    def create_serial_object(self):
        serial_port = 'COM6'      #EDIT HERE FOR PORT CHANGE
        baud_rate = 9600
        self.ser = serial.Serial(serial_port, baud_rate)
        self.change_number()

    def change_number(self):
        if self.ser.in_waiting:
            line = self.ser.readline().decode().strip()
            self.serial_label.config(text="Current Angle: " + line)
            if line == self.angles[self.index]:
                self.index += 1
                if self.index < len(self.angles):
                    self.number_label.config(text="Next Angle: " + self.angles[self.index])
                else:
                    self.number_label.config(text="Well Done! \nYou have reached the end of the piece!")
                    return

        self.root.after(100, self.change_number)

    def on_canvas_scroll(self, event):
        self.canvas.yview_scroll(-1 * (event.delta // 120), "units")
