import tkinter as tk
from secondary import SetUpScoreWindow

root = tk.Tk()
root.wm_iconbitmap('TheraNoteIcon.ico')
root.title("TheraNote")
root.geometry("1000x750")

label1 = tk.Label(root, text="Welcome to TheraNote", font=('Arial, 26'))
label1.pack(padx=40, pady=40)

label2 = tk.Label(root, text="Please Select the difficulty", font=('Arial, 18'))
label2.pack(padx=40, pady=40)


def open_elementary_window():
    elementary_window = tk.Toplevel(root)
    app = SetUpScoreWindow(elementary_window,
                           ["3", "2", "1", "2", "3", "3", "3", "2", "2", "2", "3", "3", "3", "3", "2", "1", "2", "3",
                            "3", "3", "2", "2", "3", "2", "1"], "Mary had a little lamb-simplifie.png")
    root.mainloop()


def open_intermediate_window():
    intermediate_window = tk.Toplevel(root)
    app = SetUpScoreWindow(intermediate_window,
                           ["1", "3", "3", "3", "2", "1", "5", "5", "4", "3", "3", "3", "2", "1", "5", "5", "4", "3",
                            "4", "5", "4", "3", "2", "4", "5", "4", "3", "4", "5", "6", "5", "1", "5", "4", "3", "4",
                            "5", "6", "5", "1" "6", "5", "4", "3", "2", "1", "2", "1"], "Vivaldi Spring-simplified.png")
    root.mainloop()


def open_advanced_window():
    advanced_window = tk.Toplevel(root)
    app = SetUpScoreWindow(advanced_window, ["5", "1", "2", "3", "4", "5", "1", "1", "6", "4", "5", "6", "7", "8", "1",
                                             "1", "4", "5", "4", "3", "2", "3", "4", "3", "2", "1", "2", "1", "2", "3",
                                             "1", "2", "5", "1", "2", "3", "4", "5", "1", "1", "6", "4", "5", "6", "7",
                                             "8", "1",
                                             "1", "4", "5", "4", "3", "2", "3", "4", "3", "2", "1", "2", "3", "2", "1",
                                             "1"], "Bach Minuet-simplified.png")
    root.mainloop()


# Create frame for buttons

buttonframe = tk.Frame(root)
buttonframe.pack()
buttonframe.grid_columnconfigure(0, weight=1)
buttonframe.grid_columnconfigure(1, weight=1)
buttonframe.grid_columnconfigure(2, weight=1)
# Create buttons
button1 = tk.Button(buttonframe, text="Elementary \n\n Mary had a Little Lamb", font=('Arial', 18),
                    command=open_elementary_window)
button1.grid(row=0, column=0, padx=10, pady=10)

button2 = tk.Button(buttonframe, text="Intermediate \n\n Vivaldi Spring", font=('Arial', 18),
                    command=open_intermediate_window)
button2.grid(row=0, column=1, padx=10, pady=10)

button3 = tk.Button(buttonframe, text="Advanced \n\n Bach Minuet", font=('Arial', 18),
                    command=open_advanced_window)
button3.grid(row=0, column=2, padx=10, pady=10)

# Run
root.mainloop()
# "2", "3", "3", "3", "2", "2", "2", "3", "3", "3", "3", "2", "1", "2", "3","3", "3", "2", "2", "3", "2", "1"]
